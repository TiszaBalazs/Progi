﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Alkatreszbolt
{
    internal class AlkatreszController : IAlkatresz
    {


        public Alkatresz AlkatreszByCikkszam(string cikkSzam)
        {
            throw new NotImplementedException();
        }

        public List<Alkatresz> AlkatreszLista()
        {
            List<Alkatresz> alkatreszek = new List<Alkatresz>();
            string[] sorok = File.ReadAllLines("Alkatreszek.txt");
            for (int i = 1; i < sorok.Length; i++)
            {
                string[] bontas = sorok[i].Split(';');
                Alkatresz ujAlkatresz = new Alkatresz()
                {
                    Id = int.Parse(bontas[0]),
                    Nev = bontas[1],
                    Cikkszam = bontas[2],
                    Ar = int.Parse(bontas[3]),
                    Akcios = bool.Parse(bontas[4]),
                    Mennyiseg = int.Parse(bontas[5])
                };
                alkatreszek.Add(ujAlkatresz);
            }

            return alkatreszek;
        }

        public string UjAlkatresz(Alkatresz ujAlkatresz)
        {
            ujAlkatresz.Id = IdGenerator();
            StreamWriter kimenet = new StreamWriter("Alkatreszek.txt", true);
            kimenet.WriteLine(ujAlkatresz.ToString());
            kimenet.Close();
            return "Sikeres rögzítés!";
        }

        static int IdGenerator()
        {
            HashSet<int> aznositok = new HashSet<int>();
            string[] sorok = File.ReadAllLines("Alkatreszek.txt");
            for (int i = 1; i < sorok.Length; i++)
            {
                string[] bontas = sorok[i].Split(';');
                aznositok.Add(int.Parse(bontas[0]));
            }
            return aznositok.Max() + 1;
        }

        public string AlkatreszTorles(int id)
        {
            List<Alkatresz> alkatreszek = new List<Alkatresz>();
            string[] sorok = File.ReadAllLines("Alkatreszek.txt");
            for (int i = 1; i < sorok.Length; i++)
            {
                string[] bontas = sorok[i].Split(';');
                Alkatresz ujAlkatresz = new Alkatresz()
                {
                    Id = int.Parse(bontas[0]),
                    Nev = bontas[1],
                    Cikkszam = bontas[2],
                    Ar = int.Parse(bontas[3]),
                    Akcios = bool.Parse(bontas[4]),
                    Mennyiseg = int.Parse(bontas[5])
                }; 
                alkatreszek.Add(ujAlkatresz);

            }
            int index = 0;
            while (index < alkatreszek.Count && alkatreszek[index].Id != id)
            {
                index++;
            }
            if(index < alkatreszek.Count)
            {
                alkatreszek.RemoveAt(index);
            }
            else
            {
                return "Nincs ilyen Id";
            }
            StreamWriter kimenet = new StreamWriter("Alkatreszek.txt");
            kimenet.WriteLine("Id;Nev;Cikkszam;Ar;Akcios;Mennyiseg;");
            foreach (Alkatresz alk in alkatreszek)
            {
                kimenet.WriteLine(alk.ToString());
            }
            kimenet.Close();
            return "Sikeres törlés";
        }
    }
}
