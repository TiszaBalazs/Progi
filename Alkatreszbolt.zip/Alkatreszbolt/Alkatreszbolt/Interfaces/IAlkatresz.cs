﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alkatreszbolt
{
    internal interface IAlkatresz
    {
        List<Alkatresz> AlkatreszLista();

        Alkatresz AlkatreszByCikkszam(string cikkSzam);

        string UjAlkatresz(Alkatresz ujAlkatresz);

        string AlkatreszTorles(int id);


    }
}
