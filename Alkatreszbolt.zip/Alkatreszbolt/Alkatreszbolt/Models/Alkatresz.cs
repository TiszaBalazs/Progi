﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alkatreszbolt
{
    internal class Alkatresz
    {
        public int Id { get; set; }
        public string Nev {  get; set; }

        public string Cikkszam { get; set;}

        public int Ar { get; set; }

        public bool Akcios { get; set;}

        public int Mennyiseg {  get; set; }

        public Alkatresz() { }
            
        public override string ToString()
        {
            return $"{Id};{Nev};{Cikkszam};{Ar};{Akcios.ToString()};{Mennyiseg}";
        }



    }
}
