﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Alkatreszbolt
{
    /// <summary>
    /// Interaction logic for UjAlkatreszWindow.xaml
    /// </summary>
    public partial class UjAlkatreszWindow : Window
    {
        static AlkatreszController controller;
        public UjAlkatreszWindow()
        {
            controller = new AlkatreszController();
            InitializeComponent();
        }

        private void btnRogzit_Click(object sender, RoutedEventArgs e)
        {
            Alkatresz ujAlkatresz = new Alkatresz()
            {
                Id = 0,
                Nev = tbxNev.Text,
                Cikkszam = tbxCikkszam.Text,
                Ar = int.Parse(tbxAr.Text),
                Akcios = cbxAkcios.IsChecked == true,
                Mennyiseg = int.Parse(tbxMennyiseg.Text),
            };
            string uzenet = controller.UjAlkatresz(ujAlkatresz);
            MessageBox.Show(uzenet);
            Close();
        }

        private void btnMegse_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
