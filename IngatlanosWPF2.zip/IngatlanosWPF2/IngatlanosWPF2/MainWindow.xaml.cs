﻿using Ingatlanos;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IngatlanosWPF2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static List<Ingatlan> ingatlanok = new List<Ingatlan>();
        public static List<Ingatlan> megjelenitett = new List<Ingatlan>();
        public MainWindow()
        {
            InitializeComponent();
            dgrMegjelenitett.ItemsSource = megjelenitett;
        }

        private void BeolvasasAllomanybol(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog()
            {
                FileName = "ingatlanok.txt"
            };
            if(ofd.ShowDialog() == true)
            {
                try
                {
                    string[] bemenet = File.ReadAllLines(ofd.FileName);
                    for (int i = 1; i < bemenet.Length; i++)
                    {
                        ingatlanok.Add(new Ingatlan(bemenet[i]));
                    }
                    MessageBox.Show($"Sikeres feltöltés. Beolvasott sorok száma: {ingatlanok.Count}");
                    megjelenitett.Clear();
                    foreach (Ingatlan ing in ingatlanok)
                    {
                        
                    }
                }
                catch(FileNotFoundException fex) 
                {
                    MessageBox.Show($"{fex.Message}");
                }
                catch (ArgumentNullException aex)
                {
                    MessageBox.Show($"{aex.Message}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"{ex.Message}");
                }
            }
            
            ofd.ShowDialog();
            
        }
    }
}
