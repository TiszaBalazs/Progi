﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ingatlanos
{
    public class Ingatlan : IVagyoszerzesi
    {
        private const double ILLETEK = 4.0;
        public Ingatlan(int id, string telepules, string cim, int telekmeret, int alapterulet, int ar)
        {
            Id = id;
            Telepules = telepules;
            Cim = cim;
            Telekmeret = telekmeret;
            Alapterulet = alapterulet;
            Ar = ar;
        }

        public Ingatlan(string sor)
        {
            string[] bontas = sor.Split(';');
            Id = int.Parse(bontas[0]);
            Telepules = bontas[1];
            Cim = bontas[2];
            Alapterulet = int.Parse(bontas[3]);
            Telekmeret = int.Parse(bontas[4]);
            Ar = int.Parse(bontas[5]);
        }

        public int Id { get; set; }
        public string Telepules { get; set; }
        public string Cim { get; set; }
        public int Telekmeret { get; set; }
        public int Alapterulet { get; set; }
        public int Ar {  get; set; }

        public int Illetek()
        {
            int elmeleti = (int)Math.Round(Ar * ILLETEK / 100);
            if (elmeleti >= 2000000)
                return 2000000;
            else if (elmeleti >= 10000)
                return elmeleti;
            else
                return 10000;
                
        }

        public double Beepitve()
        {
            if (Telekmeret > 0)
                return Math.Round((double)Alapterulet / Telekmeret * 100, 2);
            else
                return 100.00;
        }

        public override string ToString()
        {
            return $"Település: {Telepules}, {Cim}\n" +
                $"Alapterület: {Alapterulet} m^2, Telekméret: {Telekmeret} m^2\nÁr: {Ar} Ft";
        }
    }
}
