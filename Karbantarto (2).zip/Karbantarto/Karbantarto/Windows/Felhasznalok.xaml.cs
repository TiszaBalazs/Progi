﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ServiceReference1;

namespace Karbantarto.Windows
{
    /// <summary>
    /// Interaction logic for Felhasznalok.xaml
    /// </summary>
    public partial class Felhasznalok : Window
    {
        static List<ServiceReference1.Felhasznalok> felhasznalok;
        
        public Felhasznalok()
        {
            InitializeComponent();
            felhasznalok = new Service1Client().FelhasznalokLista_CS().ToList();
            dgrFelhasznalok.ItemsSource = felhasznalok;
        }

        private void UjFelhasznaloClick(object sender, RoutedEventArgs e)
        {

        }

        private void ModositFelhasznaloClick(object sender, RoutedEventArgs e)
        {
            int aktId = (int)felhasznalok[dgrFelhasznalok.SelectedIndex].Id;
            MessageBox.Show($"Módosítani fogja {aktId} azonosítójú felhasználót!", "Módosítás megerősítése", MessageBoxButton.YesNo,MessageBoxImage.Warning);
            ServiceReference1.Felhasznalok modositottFelhasznalo = new ServiceReference1.Felhasznalok()
            {
                Id = aktId,
                LoginNev = TbxLoginNev.Text,
                HASH = "",
                SALT = "",
                Nev = TbxNev.Text,
                Jog = int.Parse(CbxJogosultsag.Text),
                Aktiv = cbAktiv.IsChecked == true,
                Email = TbxEmail.Text,
                ProfilKep = Tbxpfp.Text,
            };
            string eredmeny = new Service1Client().FelhasznaloModosit_CS(modositottFelhasznalo);
            MessageBox.Show(eredmeny);
            felhasznalok = new Service1Client().FelhasznalokLista_CS().ToList();
            dgrFelhasznalok.ItemsSource = felhasznalok;
        }

        private void TorolFelhasznaloClick(object sender, RoutedEventArgs e)
        {
            if(dgrFelhasznalok.SelectedIndex >= 0)
            { 
                int aktId = (int)felhasznalok[dgrFelhasznalok.SelectedIndex].Id;
                MessageBox.Show($"Törölni akarja a(z)  {felhasznalok[dgrFelhasznalok.SelectedIndex].Id} azonosítójú  felhasználót?","Törlés megerősítése",MessageBoxButton.YesNo,MessageBoxImage.Warning);

                string eredmeny = new Service1Client().FelhasznaloTorol_CS(aktId);
                MessageBox.Show(eredmeny);
                felhasznalok = new Service1Client().FelhasznalokLista_CS().ToList();
                dgrFelhasznalok.ItemsSource = felhasznalok;
            }

        }

        private void dgrFelhasznalok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgrFelhasznalok.SelectedIndex >= 0)
            {
                ServiceReference1.Felhasznalok aktualisFelhasznalo = felhasznalok[dgrFelhasznalok.SelectedIndex];
                TbxLoginNev.Text = aktualisFelhasznalo.LoginNev.ToString();
                TbxNev.Text = aktualisFelhasznalo.Nev.ToString();
                TbxEmail.Text = aktualisFelhasznalo.Email.ToString();
                Tbxpfp.Text = aktualisFelhasznalo.ProfilKep.ToString();
                cbAktiv.IsChecked = aktualisFelhasznalo.Aktiv;
                CbxJogosultsag.Text = aktualisFelhasznalo.Jog.ToString();
            }
            else
            {
                TbxLoginNev.Text = "";
                TbxNev.Text = "";
                TbxEmail.Text = "";
                Tbxpfp.Text = "";
                cbAktiv.IsChecked = false;
                CbxJogosultsag.Text = "";
            }
        }
    }
}
