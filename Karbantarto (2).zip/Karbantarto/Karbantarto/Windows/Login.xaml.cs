﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Karbantarto.Windows
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        private int probalkozasokSzama = 0;
        public Login()
        {
            InitializeComponent();
        }

        void CloseWindow(object sender, CancelEventArgs e)
        {
            if (!Karbantarto.Menu.bejelentkezve)
            {
                Application.Current.Shutdown();
            }
        }

        private void LoginNev_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (LoginNev.Text == "")
            {
                ImageBrush LoginNevTextImageBrush = new ImageBrush();
                LoginNevTextImageBrush.ImageSource = new BitmapImage(new Uri(@"Images\fn.jpg", UriKind.Relative));
                LoginNevTextImageBrush.AlignmentX = AlignmentX.Left;
                LoginNevTextImageBrush.AlignmentY = AlignmentY.Center;
                LoginNevTextImageBrush.Stretch = Stretch.None;
                LoginNev.Background = LoginNevTextImageBrush;
            }
            else
            {
                LoginNev.Background = null;
            }

        }

        private void Jelszo_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (Jelszo.Password == "")
            {
                ImageBrush JelszoPasswordImageBrush = new ImageBrush();
                JelszoPasswordImageBrush.ImageSource = new BitmapImage(new Uri(@"Images\pw.jpg", UriKind.Relative));
                JelszoPasswordImageBrush.AlignmentX = AlignmentX.Left;
                JelszoPasswordImageBrush.AlignmentY = AlignmentY.Center;
                JelszoPasswordImageBrush.Stretch = Stretch.None;
                Jelszo.Background = JelszoPasswordImageBrush;
            }
            else
            {
                Jelszo.Background = null;
            }


        }

        private void Bejelentkezes_Click(object sender, RoutedEventArgs e)
        {
            probalkozasokSzama++;
            ServiceReference1.Login login = new ServiceReference1.Login();
            string salt = Menu.client.GetSalt(LoginNev.Text);
            string Token = "";
            if (salt != "")
            {
                login.LoginNev = LoginNev.Text;
                login.HASH = Menu.CreateSHA256(Jelszo.Password+salt);
                Token = Menu.client.Login_CS(login);
                if (Token != "")
                {
                    Menu.bejelentkezve = true;
                }
            }
            if (Menu.bejelentkezve)
            {

                this.Close();
                MessageBox.Show("Bejelentkezve! " + Token);
            }
            else
            {
                if (probalkozasokSzama == 3)
                {
                    this.Close();
                    //Menu.bejelentkezve = false;
                    MessageBox.Show("Sikertelen bejelentkezés!");
                    //Application.Current.Shutdown();
                }
                else
                {
                    MessageBox.Show("Hibás név vagy jelszó!");
                }
            }
        }


    }
}
