﻿using System.Configuration;
using System.Data;
using System.Windows;
using Karbantarto.Windows;

namespace Karbantarto
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Login(object sender, StartupEventArgs e)
        {
            Login login = new Login();
            Application.Current.MainWindow = login;
            Menu menu = new Menu();
            login.ShowDialog();
            if (Karbantarto.Menu.bejelentkezve)
            {
                menu.mnu_dat_Felh.IsEnabled = true;
                menu.Show();
            }
        }
    }

}
