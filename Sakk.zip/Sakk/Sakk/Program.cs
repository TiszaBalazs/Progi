﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Sakk
{
    internal class Program
    {
        static List<Allas>allasok = new List<Allas>();
        static void Main(string[] args)
        {
            string[,] tabla1 = new string[8, 8];
            for (int i = 0;i < tabla1.GetLength(0);i++)
            {
                for (int j = 0;j < tabla1.GetLength(1); j++)
                {
                    tabla1[i, j] = "  ";
                }
            }
            Allas aktualisAllas = new Allas(0, "Kiss Elemér", "Nagy Zsolt", tabla1,true);
            Console.WriteLine(aktualisAllas);
            allasok.Add(aktualisAllas);
            string[] bemenet = File.ReadAllLines("Mentesek.txt");
                foreach(string sor in bemenet)
                {
                    allasok.Add(new Allas(sor));
                }
                foreach (Allas a in allasok)
                {
                    Console.WriteLine(a.ToString());
                    Console.WriteLine();
                }

                //Kivel játszott Kiss Elemér? Az összes játékostárs nevét írassa ki egymás alá!
                List<string> kissElemerJatkostarsai = new List<string>();
            foreach (Allas a in allasok)
            {
                if(a.Vilagos == "Kiss Elemér")
                    kissElemerJatkostarsai.Add(a.Sotet);
                if (a.Sotet == "Kiss Elemér")
                    kissElemerJatkostarsai.Add(a.Vilagos);

            }
            Console.WriteLine(string.Join("\n", kissElemerJatkostarsai));
            Console.WriteLine($"Az első mentett állás következő játékosa: {allasok[0].KovetkezoJatekos()}");

            //Legkorábbi mentés meghatározása
            Allas legkorabbi = allasok[0];
            for(int i = 1; i < allasok.Count; i++)
            {
                if (allasok[i].MentesiIdo < legkorabbi.MentesiIdo)
                    legkorabbi = allasok[i];
            }
            Console.WriteLine($"A legkorábbi mentés: {legkorabbi.Vilagos} és {legkorabbi.Sotet}");
            //Játszott-e Kaszparov nevű játékos? Nem tudjuk, hogy ez-e a teljes neve!

            int index = 0;
            while( index < allasok.Count && !(allasok[index].Vilagos.Contains("Kaszparov") || allasok[index].Sotet.Contains("Kaszparov")))
            {
                index++;
            }
            if (index < allasok.Count)
            {
                Console.WriteLine("Van Kaszparov a listában.");
            }
            else
            {
                Console.WriteLine("Nincs Kaszparov a listában.");
            }
            //Írassuk ki azt az állást amelyben van világos bástya a táblán
            int indey = 0;
            while (index < allasok.Count && !(TartalmazErtek(allasok[indey].Tabla,"vB")))
            {
                indey++;
            }
            if (indey < allasok.Count)
            {
                Console.WriteLine(allasok[indey]);
            }
            else
            {
                Console.WriteLine("Nincs iylen állás.");
            }
            Console.WriteLine(allasok[0].CompareTo(allasok[1]));
            allasok.Sort();
            foreach(Allas a in allasok)
            {
                Console.WriteLine(a.ToString());
                Console.WriteLine();
            }

            Console.ReadLine();
        }
        /// <summary>
        /// Az adott kétdimenziós stringtömb (mátrix) tartalmazza-e az adott stringet elemként?
        /// <param name="matrix">A kétdimenziós stringtömb</param>
        /// <param name="ertek">A keresett elem</param>
        /// </summary>
        /// <returns>True,ha tartalmazza,false egyébként.</returns>
        static bool TartalmazErtek(string[,]matrix, string ertek)
        {
            bool van = false;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0;j < matrix.GetLength(1); j++)
                {
                    if (matrix[i,j] == ertek)
                        van = true;
                }
            }

            return van;
        }
    }
}

